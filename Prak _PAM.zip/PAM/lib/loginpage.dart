import 'package:flutter/material.dart';

// ignore: camel_case_types, must_be_immutable
class loginPage extends StatefulWidget {
  loginPage({super.key});

  @override
  State<loginPage> createState() => _loginPageState();
}

// ignore: camel_case_types
class _loginPageState extends State<loginPage> {
  String username = '';

  String password = '';

  bool isLoginSuccess = true;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Welcome to Rumah kita'),
        ),
        body: Column(
          children: [
            _usernameField(),
            _passwordField(),
            _loginButton(context)
          ],
        )
      ),
    );
  }

  Widget _usernameField(){
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextFormField(
        onChanged: (value){
          username = value;
        },
        decoration: InputDecoration(
          hintText: ' Masukkan Username',
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color.fromARGB(255, 164, 171, 176))
          )
      ),
    )
    );
  }

  Widget _passwordField(){
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: TextFormField(
        onChanged: (value){
          password = value;
        },
        obscureText: true,
        decoration: InputDecoration(
          labelText: 'Masukkan Password',
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: Color.fromARGB(255, 157, 164, 171))
          )
      ),
    )
    );
  }



  Widget _loginButton(BuildContext context){
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      width: MediaQuery.of(context).size.width,
      child: ElevatedButton(
        onPressed: () {
          String text = '';
          if(username == 'kael' && password == 'kael123'){
            setState(() {
              text = 'Login Berhasil';
              isLoginSuccess = true;
            });
          } else {
            setState(() {
              text = 'Login Gagal';
              isLoginSuccess = false;
            });
          }
          SnackBar snackBar = SnackBar(
            backgroundColor: isLoginSuccess ? const Color.fromARGB(255, 82, 255, 91) : const Color.fromARGB(255, 240, 11, 11),
            content: Text(text)
            
            );
          ScaffoldMessenger.of(context).showSnackBar(snackBar);
        },
        child: const Text('Login')
        ),
    );
  }
}